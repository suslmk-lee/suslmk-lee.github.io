# AI Agent Demo Helm 차트

이 Helm 차트는 AI Agent Demo 애플리케이션을 Kubernetes 클러스터에 배포하기 위한 것입니다. 이 애플리케이션은 UI 컴포넌트, Agent A, Agent B로 구성되어 있으며, 두 개의 서로 다른 클러스터에 분산 배포할 수 있습니다.

## 기능

- 조건부 배포: 각 컴포넌트(UI, Agent A, Agent B)를 개별적으로 활성화/비활성화할 수 있습니다.
- 다중 클러스터 지원: 서로 다른 클러스터에 컴포넌트를 분산 배포할 수 있습니다.
- 클러스터 이름 설정: 각 에이전트가 실행되는 클러스터의 이름을 설정할 수 있습니다.

## 사전 요구 사항

- Kubernetes 1.16+
- Helm 3.0+
- kubectl이 설치되어 있고 클러스터에 접근 가능한 상태

## 설치 방법

### 클러스터 1 (UI와 Agent A 배포)

```bash
# values-cluster1.yaml 파일을 사용하여 클러스터 1에 배포
helm install ai-agent-demo ./helm/ai-agent-demo -f ./helm/ai-agent-demo/values-cluster1.yaml
```

### 클러스터 2 (Agent B 배포)

```bash
# values-cluster2.yaml 파일을 사용하여 클러스터 2에 배포
helm install ai-agent-demo ./helm/ai-agent-demo -f ./helm/ai-agent-demo/values-cluster2.yaml
```

## 구성 옵션

주요 구성 옵션은 다음과 같습니다:

| 파라미터 | 설명 | 기본값 |
|---------|------|-------|
| `global.imageRegistry` | 도커 이미지 레지스트리 | `44ce789b-kr1-registry.container.nhncloud.com/container-platform-registry` |
| `global.imagePullSecrets` | 이미지 풀 시크릿 이름 | `[{ name: ncr }]` |
| `global.existingImagePullSecret` | 기존 이미지 풀 시크릿 사용 여부 | `false` |
| `global.dockerConfigJson` | 도커 레지스트리 인증 정보 (base64 인코딩) | `"eyJhdXRocyI6e..."` |
| `global.namespace` | 배포할 네임스페이스 | `agent-ns` |
| `global.clusterName` | 클러스터 이름 | `default-cluster` |
| `global.clusterType` | 클러스터 타입 (cluster1 또는 cluster2) | `cluster1` |
| `ui.enabled` | UI 컴포넌트 활성화 여부 | `true` |
| `agentA.enabled` | Agent A 활성화 여부 | `true` |
| `agentB.enabled` | Agent B 활성화 여부 | `true` |
| `openai.apiKey` | OpenAI API 키 (base64로 인코딩됨) | `""` |

전체 구성 옵션은 [values.yaml](./values.yaml) 파일을 참조하세요.

## 업그레이드 및 롤백

### 업그레이드

```bash
# 클러스터 1의 차트 업그레이드
helm upgrade ai-agent-demo ./helm/ai-agent-demo -f ./helm/ai-agent-demo/values-cluster1.yaml

# 클러스터 2의 차트 업그레이드
helm upgrade ai-agent-demo ./helm/ai-agent-demo -f ./helm/ai-agent-demo/values-cluster2.yaml
```

### 롤백

```bash
# 이전 버전으로 롤백
helm rollback ai-agent-demo
```

## 제거

```bash
# 차트 제거
helm uninstall ai-agent-demo
```

## 주의사항

- OpenAI API 키는 반드시 설정해야 합니다. 기존 시크릿을 사용하거나 새로운 시크릿을 생성할 수 있습니다.
- 클러스터 간 통신이 가능해야 합니다. 특히 Agent B가 있는 클러스터에서 UI와 Agent A가 있는 클러스터로의 통신이 필요합니다.
